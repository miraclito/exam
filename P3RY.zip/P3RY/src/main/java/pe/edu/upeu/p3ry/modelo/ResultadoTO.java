/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.upeu.p3ry.modelo;

import lombok.Data;


/**
 *
 * @author HIRAM
 */

@Data
public class ResultadoTO {
     public int IdResultado, punto;
    public String nombre_partida, nombre_jugador1, nombre_jugador2, ganador, estado;
}
