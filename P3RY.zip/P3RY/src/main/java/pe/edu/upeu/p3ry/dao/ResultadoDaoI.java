/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package pe.edu.upeu.p3ry.dao;

import java.util.List;
import pe.edu.upeu.p3ry.modelo.ResultadoTO;

/**
 *
 * @author HIRAM
 */
public interface ResultadoDaoI {
     public List<ResultadoTO> listarResultados();

    public int update(ResultadoTO d);
    public int delete(int id);
    

    public int crearResultado(ResultadoTO re);
}
